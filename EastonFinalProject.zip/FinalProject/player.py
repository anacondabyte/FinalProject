#Program name: player.py
#Author: David Easton
#Date: 5/2/2022
#Summary: Create a base class for battlers. This is the base for the hero and
# monsters.
#Variables:
#-------From Battler Class------------
# self.name: String for the class's name
# self.skillLimit: Limits amount of skills equipped (Up to 4)
# self.skill_1 (class Skills) - skill used by battler
# self.skill_2 (class Skills) - skill used by battler
# self.skill_3 (class Skills) - skill used by battler
# self.skill_4 (class Skills) - skill used by battler
# self.element: 0-6 value to determine element (
# self.health: Int value for base health
# self.attack: Int value for base attack
# self.defense: Int value for base defense
# self.speed: Int value for base speed
# self.BLANK: skill that is static and used for clearing data


#Create Monster class
from battler import Battler
def Player(Battler):
    def __init__(self, name, element, health, attack, defense, speed, skill1, skill2, skill3, skill4):
        Battler.__init__(self, name, element, health, attack, defense, speed)
        #determine player skills
        self.setSkill_1(skill1)
        self.setSkill_2(skill2)
        self.setSkill_3(skill3)
        self.setSkill_4(skill4)
    #Accessors
    #Get Battler Name
    def getBattlerName(self):
        return self.name
    #Get Battler Elemental Value
    def getBattlerElement(self):
        return self.element
    #Get Battler Health
    def getBattlerHealth(self):
        return self.health
    #Get Battler Attack
    def getBattlerAttack(self):
        return self.attack
    #Get Battler Defense
    def getBattlerDefense(self):
        return self.defense
    #Get Battler Speed
    def getBattlerSpeed(self):
        return self.speed
    #Get Battler Skills
    def getSkill_1(self):
        return self.skill_1
    def getSkill_2(self):
        return self.skill_2
    def getSkill_3(self):
        return self.skill_3
    def getSkill_4(self):
        return self.skill_4
    #Mutators
    #Set Battler Name
    def setBattlerName(self, name):
        self.name = name
    #Set Battler Elemental Value
    def setBattlerElement(self, element):
        self.element = element
    #Set Battler Health
    def setBattlerHealth(self, health):
        self.health = health
    #Set Battler Attack
    def setBattlerAttack(attack):
        self.attack = health
    #Set Battler Defense
    def setBattlerDefense(self, defense):
        self.defense = defense
    #Set Battler Speed
    def setBattlerSpeed(speed):
        self.speed = speed
    #Set Battler Skills
    def setSkill_1(self, skill):
        self.skill_1.setSkill(skill)
    def setSkill_2(self, skill):
        self.skill_2.setSkill(skill)
    def setSkill_3(self, skill):
        self.skill_3.setSkill(self, skill)       
    def setSkill_4(skill):
        self.skill_4.setSkill(self, skill)
    #Clearing Skills
    def clearSkills(self):
        self.skill_1.setSkill(self.BLANK)
        self.skill_2.setSkill(self.BLANK)
        self.skill_3.setSkill(self.BLANK)
        self.skill_4.setSkill(self.BLANK)
